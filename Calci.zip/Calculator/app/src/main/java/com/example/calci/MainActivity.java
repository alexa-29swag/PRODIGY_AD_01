package com.example.calci;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView result, solution;
    MaterialButton buttonC, buttonBrackOpen, buttonBrackClose;
    MaterialButton buttonDivide, buttonPlus, buttonMinus, buttonMultiply, buttonEquals;
    MaterialButton button0, button1, button2, button3, button4, button5, button6, button7, button8, button9;
    MaterialButton buttonAC, buttonDot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        result = findViewById(R.id.result);
        solution = findViewById(R.id.solution);

        // Fixed: Proper assignment of buttons
        buttonC = findViewById(R.id.btn_c);
        buttonBrackOpen = findViewById(R.id.btn_openbracket);
        buttonBrackClose = findViewById(R.id.btn_closebracket);
        buttonDivide = findViewById(R.id.btn_divide);
        buttonPlus = findViewById(R.id.btn_add);
        buttonMinus = findViewById(R.id.btn_sub);
        buttonMultiply = findViewById(R.id.btn_multiply);
        buttonEquals = findViewById(R.id.btn_equals);
        button0 = findViewById(R.id.btn_0);
        button1 = findViewById(R.id.btn_1);
        button2 = findViewById(R.id.btn_2);
        button3 = findViewById(R.id.btn_3);
        button4 = findViewById(R.id.btn_4);
        button5 = findViewById(R.id.btn_5);
        button6 = findViewById(R.id.btn_6);
        button7 = findViewById(R.id.btn_7);
        button8 = findViewById(R.id.btn_8);
        button9 = findViewById(R.id.btn_9);
        buttonAC = findViewById(R.id.btn_ac);
        buttonDot = findViewById(R.id.btn_dot);

        // Set all buttons to listen
        setListeners();
    }

    void setListeners() {
        int[] btnIDs = {
                R.id.btn_c, R.id.btn_openbracket, R.id.btn_closebracket,
                R.id.btn_divide, R.id.btn_add, R.id.btn_sub, R.id.btn_multiply, R.id.btn_equals,
                R.id.btn_0, R.id.btn_1, R.id.btn_2, R.id.btn_3, R.id.btn_4, R.id.btn_5, R.id.btn_6,
                R.id.btn_7, R.id.btn_8, R.id.btn_9, R.id.btn_ac, R.id.btn_dot
        };
        for (int id : btnIDs) {
            MaterialButton btn = findViewById(id);
            btn.setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View view) {
        MaterialButton button = (MaterialButton) view;
        String buttonText = button.getText().toString();
        String dataToCalculate = solution.getText().toString();

        if (buttonText.equals("AC")) {
            solution.setText("");
            result.setText("0");
            return;
        }

        if (buttonText.equals("=")) {
            solution.setText(result.getText());
            return;
        }

        if (buttonText.equals("C")) {
            // Fixed: Avoid index out of bounds
            if (!dataToCalculate.isEmpty()) {
                dataToCalculate = dataToCalculate.substring(0, dataToCalculate.length() - 1);
            }
        } else {
            dataToCalculate = dataToCalculate + buttonText;
        }

        solution.setText(dataToCalculate);

        String finalResult = getResult(dataToCalculate);
        if (!finalResult.equals("Error")) {
            result.setText(finalResult);
        }
    }

    String getResult(String data) {
        if (data.isEmpty()) {
            return "0";
        }

        try {
            Context context = Context.enter();
            context.setOptimizationLevel(-1);
            Scriptable scriptable = context.initStandardObjects();
            Object result = context.evaluateString(scriptable, data, "JavaScript", 1, null);

            if (result == Context.getUndefinedValue()) {
                return "0";
            }

            String finalResult = result.toString();

            if (finalResult.endsWith(".0")) {
                finalResult = finalResult.replace(".0", "");
            }

            return finalResult;
        } catch (Exception e) {
            return "Error";
        } finally {
            Context.exit();
        }
    }

}
